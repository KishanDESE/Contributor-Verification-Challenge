#!/usr/bin/env python3
import pandas as pd
import json

# -------------------------------
# Load CSV and JSON
# -------------------------------
csv_path = "test_features.csv"
json_path = "test.json"

df = pd.read_csv(csv_path)

with open(json_path, "r") as f:
    data = json.load(f)

# -------------------------------
# Update NumContributor column
# -------------------------------
def get_num_contributors(article_id):
    article = data.get(str(article_id))  # JSON keys are strings
    if article is None:
        return 0  # or NaN if you prefer
    contributors = article.get("contributor", [])
    return max(len(contributors), 0)  # n-1, min 0

# Apply to the CSV
df['NumContributor'] = df['id'].apply(get_num_contributors)

# -------------------------------
# Save updated CSV
# -------------------------------
df.to_csv("test_feature_updated.csv", index=False)
print("Updated CSV saved as train_feature_updated.csv")
