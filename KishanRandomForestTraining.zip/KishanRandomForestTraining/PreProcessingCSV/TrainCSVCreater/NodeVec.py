# =====================================================
# PART 0: Imports
# =====================================================
import json
from collections import defaultdict
import numpy as np
import networkx as nx
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import TruncatedSVD
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from node2vec import Node2Vec

# =====================================================
# PART 1: Load JSON data
# =====================================================
with open("train.json") as f:
    data = json.load(f)

def ensure_list(x):
    """Convert integer or list to list"""
    if x is None:
        return []
    return x if isinstance(x, list) else [x]



# =====================================================
# PART 2: Build Contributor TF-IDF representation
# =====================================================
def build_contributor_tfidf(data):
    contributor_texts = defaultdict(list)
    
    for article in data.values():
        contributors = article.get("contributor", [])
        if not contributors:
            continue
        contributors = contributors if isinstance(contributors, list) else [contributors]

        # Ensure text is a list
        text_ids = ensure_list(article.get("text"))
        for c in contributors:
            contributor_texts[c].extend(text_ids)
    
    documents = [" ".join(map(str, texts)) for texts in contributor_texts.values()]
    contributor_ids = list(contributor_texts.keys())
    
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(documents)
    
    return contributor_ids, tfidf_matrix


# =====================================================
# PART 3: Optional Dimensionality Reduction
# =====================================================
def reduce_tfidf_dim(tfidf_matrix, n_components=128):
    svd = TruncatedSVD(n_components=n_components, random_state=42)
    reduced_matrix = svd.fit_transform(tfidf_matrix)
    return reduced_matrix

# =====================================================
# PART 4: Build TF-IDF similarity graph
# =====================================================
def build_tfidf_similarity_graph(contributor_ids, tfidf_matrix):
    """
    Build weighted undirected graph where edge weight = TF-IDF cosine similarity.
    Only include edges above threshold = mean + 0.5*std
    """
    sim_matrix = cosine_similarity(tfidf_matrix)
    mean_sim = sim_matrix.mean()
    std_sim = sim_matrix.std()
    threshold = mean_sim + 0.5 * std_sim
    print(f"Using threshold = {threshold:.4f} for edge creation")

    G = nx.Graph()
    
    # Add nodes
    for c in contributor_ids:
        G.add_node(c)
    
    # Add edges
    for i, c1 in enumerate(contributor_ids):
        for j in range(i+1, len(contributor_ids)):
            c2 = contributor_ids[j]
            weight = sim_matrix[i, j]
            if weight > threshold:
                G.add_edge(c1, c2, weight=weight)
    
    return G

# =====================================================
# PART 5: Train Node2Vec embeddings
# =====================================================
def train_node2vec(G, dimensions=512, walk_length=50, num_walks=100, workers=24):
    node2vec = Node2Vec(
        G,
        dimensions=dimensions,
        walk_length=walk_length,
        num_walks=num_walks,
        workers=workers,
        weight_key='weight'
    )
    model = node2vec.fit(window=10, min_count=1, batch_words=4)
    return model

# =====================================================
# PART 6: Save / Load Node2Vec model and get contributor embedding
# =====================================================
def save_node2vec_model(model, path="node2vec_model.kv"):
    model.wv.save(path)

def load_node2vec_model(path="node2vec_model.kv"):
    from gensim.models import KeyedVectors
    return KeyedVectors.load(path, mmap='r')

def get_contributor_embedding(model, contributor_id):
    return model[str(contributor_id)]

# =====================================================
# PART 7: Cosine similarity with coauthors
# =====================================================
def max_cosine_similarity_with_coauthors(model, candidate_id, coauthor_ids):
    # Candidate embedding
    candidate_emb = get_contributor_embedding(model, candidate_id).reshape(1, -1)
    
    # Coauthors embeddings
    coauthor_embs = np.array([get_contributor_embedding(model, c) for c in coauthor_ids])
    
    # Cosine similarity: shape (1, len(coauthor_ids))
    sim = cosine_similarity(candidate_emb, coauthor_embs).flatten()
    
    # Find index of maximum similarity
    max_idx = np.argmax(sim)
    max_sim = sim[max_idx]
    best_coauthor_id = coauthor_ids[max_idx]
    
    return max_sim, best_coauthor_id


def cosine_similarity_between_contributors(model, contributor_id1, contributor_id2):
    # Get embeddings
    emb1 = get_contributor_embedding(model, contributor_id1).reshape(1, -1)
    emb2 = get_contributor_embedding(model, contributor_id2).reshape(1, -1)  
    # Cosine similarity
    sim = cosine_similarity(emb1, emb2)[0, 0]
    return sim

# =====================================================
# PART 8: Plot 2D projection of embeddings
# =====================================================
def plot_node2vec_2d(model, contributor_ids, out_file="node2vec_2d.png"):
    embeddings = np.array([model.wv[str(c)] for c in contributor_ids])
    tsne = TSNE(n_components=2, random_state=42)
    embeddings_2d = tsne.fit_transform(embeddings)
    
    plt.figure(figsize=(10, 8))
    plt.scatter(embeddings_2d[:,0], embeddings_2d[:,1], s=20)
    for i, c in enumerate(contributor_ids):
        plt.text(embeddings_2d[i,0], embeddings_2d[i,1], str(c), fontsize=6)
    plt.title("Node2Vec 2D projection")
    plt.savefig(out_file, dpi=300)
    plt.close()
    print(f"2D projection saved to {out_file}")

# =====================================================
# PART 9: Full pipeline execution
# =====================================================
if __name__ == "__main__":
    # Build TF-IDF
    contributor_ids, tfidf_matrix = build_contributor_tfidf(data)
    
    # Optional: Dimensionality reduction
    tfidf_matrix_reduced = reduce_tfidf_dim(tfidf_matrix, n_components=128)
    
    # Build TF-IDF similarity graph using smart threshold
    G = build_tfidf_similarity_graph(contributor_ids, tfidf_matrix_reduced)
    print(f"Graph has {G.number_of_nodes()} nodes and {G.number_of_edges()} edges")
    
    # Train Node2Vec embeddings
    node2vec_model = train_node2vec(G, dimensions=512)
    
    # Save Node2Vec model
    save_node2vec_model(node2vec_model, "node2vec_model.kv")
    
    # Example: max cosine similarity of candidate with first 5 coauthors
    candidate = contributor_ids[0]
    coauthors = contributor_ids[1:5]
    max_sim,best_coauthor = max_cosine_similarity_with_coauthors(node2vec_model, candidate, coauthors)
    print("Max cosine similarity with coauthors:", max_sim)
    print("Best coauthors:", best_coauthor)
    
    # Plot 2D projection
    plot_node2vec_2d(node2vec_model, contributor_ids)
