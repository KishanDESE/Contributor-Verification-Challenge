import json
import numpy as np
import pandas as pd
from itertools import product
from tqdm import tqdm
import random
from sklearn.metrics.pairwise import cosine_similarity
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing

# -------------------------
# Import all your functions
# -------------------------
from PMICall import getPMI_between_contributors, contributor_venue_pmi, contributor_year_pmi
from Graph_Builder import (
    shortest_path_to_coauthors,
    shortest_path_between_contributors,
    shortest_path_to_topic,
    shortest_path_to_venue,
    degree_centrality_candidate,
    hops_to_venue,
    hops_to_topic,
)
from LDACallFunction import get_topic_distribution
from ClArticleNo import get_article_count
from ClTextCandidate import get_semantic_similarity
from ClCoAuthorCount import get_coauthor_features

# -------------------------
# Node2Vec safe helpers
# -------------------------
from gensim.models import KeyedVectors

NODE2VEC_MODEL_PATH = "node2vec_model.kv"
node2vec_model = KeyedVectors.load(NODE2VEC_MODEL_PATH)
EMBED_DIM = node2vec_model.vector_size
avg_contributors = np.load("contributor_avg.npy", allow_pickle=True).item()

def safe_get_embedding(contributor_id, dim=EMBED_DIM):
    try:
        if str(contributor_id) in node2vec_model:
            return node2vec_model[str(contributor_id)]
        elif int(contributor_id) in node2vec_model:
            return node2vec_model[int(contributor_id)]
        else:
            return np.zeros(dim, dtype=float)
    except Exception:
        return np.zeros(dim, dtype=float)

def safe_cosine_similarity(contrib1, contrib2):
    try:
        emb1 = safe_get_embedding(contrib1).reshape(1, -1)
        emb2 = safe_get_embedding(contrib2).reshape(1, -1)
        return float(cosine_similarity(emb1, emb2)[0][0])
    except Exception:
        return 0.0

# -------------------------
# Helper functions
# -------------------------
def ensure_list(x):
    if x is None:
        return []
    elif isinstance(x, list):
        return x
    else:
        return [x]

def generate_pairs(possible_candidates, possible_contributors):
    return [(c, p) for c, p in product(possible_candidates, possible_contributors) if c != p]

def generate_negative_candidates(unique_contributors, existing_candidates, n=3):
    available = list(set(unique_contributors) - set(existing_candidates))
    if len(available) == 0:
        return []
    return random.sample(available, min(n, len(available)))

# -------------------------
# Load data
# -------------------------
TRAIN_JSON_PATH = "train.json"
UNIQUE_CONTRIB_PATH = "unique_contri_n_candidates.npy"

with open(TRAIN_JSON_PATH, "r") as f:
    data = json.load(f)

if isinstance(data, dict):
    articles = list(data.values())
elif isinstance(data, list):
    articles = data
else:
    raise ValueError("Unexpected JSON format")

unique_contributors = np.load(UNIQUE_CONTRIB_PATH, allow_pickle=True).tolist()

# -------------------------
# Function to process one article
# -------------------------
def process_article(article):
    rows = []
    text_ids = ensure_list(article.get("text", []))
    venue = article.get("article_venue", "")
    v = -1 if venue == "" else venue
    y = article.get("article_year", None)
    topic_probs = get_topic_distribution({"text": text_ids})
    t = int(np.argmax(topic_probs))

    possible_candidates = ensure_list(article.get("possible_candidates", []))
    possible_contributors = ensure_list(article.get("possible_contributors", []))
    pairs = generate_pairs(possible_candidates, possible_contributors)

    for c, p in pairs:
        W2V = get_semantic_similarity(c, text_ids)
        N2Vsim = safe_cosine_similarity(c, p)
        C_CPMI = getPMI_between_contributors(c, p)
        C_CDist = shortest_path_between_contributors(c, p)
        AvgContributor = avg_contributors.get(c, 0.0)
        VenuePMI = contributor_venue_pmi("author_venue_pmi.npz", c, v) if v != -1 else -0.6412474179895141
        YearPMI = contributor_year_pmi("contributor_year_pmi.npz", c, y) if y is not None else 0.0
        C_TDist = shortest_path_to_topic(c, t)
        C_VDist = shortest_path_to_venue(c, v) if v != -1 else 0.2079472163772521
        Degree = degree_centrality_candidate(c)
        H2V = hops_to_venue(c, v) if v != -1 else 1
        H2T = hops_to_topic(c, t)
        ArticleCount = get_article_count(c)
        v_val = v if v != -1 else 1

        row = {
            "id": article.get("id"),
            "Candidate": c,
            "CoAuthor": p,
            "N2Vsim": N2Vsim,
            "C_CDist": C_CDist,
            "C_TDist": C_TDist,
            "C_VDist": C_VDist,
            "Degree": Degree,
            "H2V": H2V,
            "H2T": H2T,
            "label": 1,
            "ArticleCount": ArticleCount,
            "W2V": W2V,
            "AvgContributor": AvgContributor,
            "C_CPMI": C_CPMI,
            "VenuePMI": VenuePMI,
            "YearPMI": YearPMI,
            "venue": v_val,
            "topic": t,
            "year": y,
            "NumContributor":0,
        }
        
        for tp in range(21):
                    row[f"Topic{tp}"] = float(topic_probs[tp])
        rows.append(row)
        

        # Negative samples
        existing = set(possible_candidates + possible_contributors)
        negative_candidates = generate_negative_candidates(unique_contributors, existing, n=3)
        for c_neg in negative_candidates:
            W2V_neg = get_semantic_similarity(c_neg, text_ids)
            N2Vsim_neg = safe_cosine_similarity(c_neg, p)
            C_CPMI_neg = getPMI_between_contributors(c_neg, p)
            C_CDist_neg = shortest_path_between_contributors(c_neg, p)
            AvgContributor_neg = avg_contributors.get(c_neg, 0.0)
            VenuePMI_neg = contributor_venue_pmi("author_venue_pmi.npz", c_neg, v) if v != -1 else -0.6412474179895141
            YearPMI_neg = contributor_year_pmi("contributor_year_pmi.npz", c_neg, y) if y is not None else 0.0
            C_TDist_neg = shortest_path_to_topic(c_neg, t)
            C_VDist_neg = shortest_path_to_venue(c_neg, v) if v != -1 else 0.2079472163772521
            Degree_neg = degree_centrality_candidate(c_neg)
            H2V_neg = hops_to_venue(c_neg, v) if v != -1 else 1
            H2T_neg = hops_to_topic(c_neg, t)
            ArticleCount_neg = get_article_count(c_neg)


            neg_row = {
                "id": article.get("id"),
                "Candidate": c_neg,
                "CoAuthor": p,
                "N2Vsim": N2Vsim_neg,
                "C_CDist": C_CDist_neg,
                "C_TDist": C_TDist_neg,
                "C_VDist": C_VDist_neg,
                "Degree": Degree_neg,
                "H2V": H2V_neg,
                "H2T": H2T_neg,
                "label": 0,
                "ArticleCount": ArticleCount_neg,
                "W2V": W2V_neg,
                "AvgContributor": AvgContributor_neg,
                "C_CPMI": C_CPMI_neg,
                "VenuePMI": VenuePMI_neg,
                "YearPMI": YearPMI_neg,
                "venue": v_val,
                "topic": t,
                "year": y,
                "NumContributor":0,
            }
            for tp in range(21):
                    neg_row[f"Topic{tp}"] = float(topic_probs[tp])
            rows.append(neg_row)
    return rows

# -------------------------
# Parallel processing
# -------------------------
num_cores = 100
all_rows = []

with ProcessPoolExecutor(max_workers=num_cores) as executor:
    futures = [executor.submit(process_article, article) for article in articles]
    for f in tqdm(as_completed(futures), total=len(futures), desc="Processing articles"):
        all_rows.extend(f.result())

# -------------------------
# Save CSV
# -------------------------
df = pd.DataFrame(all_rows)
df.to_csv("train_features.csv", index=False)
print(f"Saved CSV with {len(all_rows)} rows to train_features.csv")
