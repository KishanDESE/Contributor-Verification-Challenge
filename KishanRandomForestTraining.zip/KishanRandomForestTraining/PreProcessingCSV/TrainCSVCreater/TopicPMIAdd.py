import pandas as pd
import numpy as np
import math

# ---------- Step 1: Load train data ----------
train_df = pd.read_csv("zero_only_train.csv", sep=",")

# Count total samples
N = len(train_df)

# Count frequencies
cand_counts = train_df["candidate"].value_counts()
topic_counts = train_df["max_topic"].value_counts()
joint_counts = train_df.groupby(["candidate", "max_topic"]).size()

# Compute PMI matrix
PMI_matrix = {}
for (cand, topic), joint in joint_counts.items():
    p_ct = joint / N
    p_c = cand_counts[cand] / N
    p_t = topic_counts[topic] / N
    PMI_matrix[(cand, topic)] = math.log(p_ct / (p_c * p_t) + 1e-12)  # avoid log(0)

# ---------- Step 2: Add TopicPMI column to train ----------
train_df["TopicPMI"] = train_df.apply(
    lambda row: PMI_matrix.get((row["candidate"], row["max_topic"]), 0.0), axis=1
)

train_df.to_csv("zero_only_trainPMITh.csv", index=False)

# ---------- Step 3: Load test data ----------
test_df = pd.read_csv("zero_only_test.csv", sep=",")

# Add TopicPMI using the *train* PMI matrix
test_df["TopicPMI"] = test_df.apply(
    lambda row: PMI_matrix.get((row["candidate"], row["max_topic"]), 0.0), axis=1
)

test_df.to_csv("zero_only_testPMITh.csv", index=False)

print("Done. New columns added to both train and test CSVs.")
