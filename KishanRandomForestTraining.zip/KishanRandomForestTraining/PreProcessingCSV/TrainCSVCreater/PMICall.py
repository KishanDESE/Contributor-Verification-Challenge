import numpy as np
import json


PMI = np.load("PMI_CandidateMax.npy")
with open("contributor_index.json", "r") as f:
    contributor_index = json.load(f)
    # keys are strings (JSON spec), convert values to int
    contributor_index = {int(k): v for k, v in contributor_index.items()}

def getMaxPMI_Contributor(savedPMI, contributorID1, contributorList):
    """
    Returns (max_PMI_value, best_contributorID)
    where best_contributorID is from contributorList
    """
    if contributorID1 not in contributor_index:
        raise ValueError(f"Contributor {contributorID1} not found in index")

    idx1 = contributor_index[contributorID1]
    max_val = -np.inf
    best_contrib = None

    for c in contributorList:
        if c not in contributor_index:
            continue
        idx2 = contributor_index[c]
        val = savedPMI[idx1, idx2]
        if val > max_val:
            max_val = val
            best_contrib = c

    # If no valid contributor found, return None
    if best_contrib is None:
        return None, None
    return max_val, best_contrib



def getPMI_between_contributors(contributorID1, contributorID2,
                                pmi_file="PMI_CandidateMax.npy",
                                index_file="contributor_index.json"):
    """
    Returns the PMI value between two contributors.
    Loads PMI matrix and contributor index from disk by default.
    """
    # Load PMI matrix
    savedPMI = np.load(pmi_file)
    
    # Load contributor index (keys are strings in JSON, convert to int)
    with open(index_file, "r") as f:
        contributor_index = json.load(f)
        contributor_index = {int(k): v for k, v in contributor_index.items()}

    if contributorID1 not in contributor_index:
        raise ValueError(f"Contributor {contributorID1} not found in index")
    if contributorID2 not in contributor_index:
        raise ValueError(f"Contributor {contributorID2} not found in index")

    idx1 = contributor_index[contributorID1]
    idx2 = contributor_index[contributorID2]

    return savedPMI[idx1, idx2]





def contributor_venue_pmi(npz_file, contributor_id, venue_id):
    """
    Load Author-Venue PMI and return PMI for given contributor and venue.

    Args:
        npz_file (str): Path to saved .npz file
        contributor_id (int)
        venue_id (int or str)

    Returns:
        float: PMI value or None if not found
    """
    loaded = np.load(npz_file, allow_pickle=True)
    pmi_matrix = loaded["pmi_matrix"]
    all_authors = loaded["all_authors"].tolist()
    all_venues = loaded["all_venues"].tolist()

    if contributor_id not in all_authors:
        raise ValueError(f"Contributor {contributor_id} not found.")
    if venue_id not in all_venues:
        raise ValueError(f"Venue {venue_id} not found.")

    idx_author = all_authors.index(contributor_id)
    idx_venue = all_venues.index(venue_id)

    return pmi_matrix[idx_author, idx_venue]





def contributor_year_pmi(npz_file, contributor_id, year_id):
    """
    Load Contributor-Year PMI and return PMI for given contributor and year.

    Args:
        npz_file (str): Path to saved .npz file
        contributor_id (int)
        year_id (int)

    Returns:
        float: PMI value or None if not found
    """
    loaded = np.load(npz_file, allow_pickle=True)
    pmi_matrix = loaded["pmi_matrix"]
    all_authors = loaded["all_authors"].tolist()
    all_years = loaded["all_years"].tolist()

    if contributor_id not in all_authors:
        raise ValueError(f"Contributor {contributor_id} not found.")
    if year_id not in all_years:
        raise ValueError(f"Year {year_id} not found.")

    idx_author = all_authors.index(contributor_id)
    idx_year = all_years.index(year_id)

    return pmi_matrix[idx_author, idx_year]


    

# ==============================
# Example usage
# ==============================
if __name__ == "__main__":
    contributor1 = 1605
    contributor_list = [759, 1414, 2182, 12345]  # example IDs (12345 not in data)

    max_pmi, sum_pmi = getMaxPMI_Contributor(PMI, contributor1, contributor_list)
    print(f"Max PMI: {max_pmi}")
    print(f"Candidate ID with Max PMII: {sum_pmi}")


#For Candidate-venue
    npz_file = "author_venue_pmi.npz"
    contributor_id = 1605
    venue_id = 5

    pmi_val = contributor_venue_pmi(npz_file, contributor_id, venue_id)
    print(f"PMI between contributor {contributor_id} and venue {venue_id}: {pmi_val}")


#For CAndidate-year
    npz_file = "contributor_year_pmi.npz"
    contributor_id = 1605
    year_id = 17

    pmi_year = contributor_year_pmi(npz_file, contributor_id, year_id)
    print(f"PMI between contributor {contributor_id} and year {year_id}: {pmi_year}")