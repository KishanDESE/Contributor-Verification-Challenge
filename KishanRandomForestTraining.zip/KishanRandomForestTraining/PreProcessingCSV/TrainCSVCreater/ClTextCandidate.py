import numpy as np
from gensim.models import Word2Vec
from numpy.linalg import norm

# Load Word2Vec
w2v_model = Word2Vec.load("word2vec.model")

# Load candidate expertise
candidate_data = np.load("candidate_expertise.npz", allow_pickle=True)
candidate_expertise_dict = {int(k): candidate_data[k] for k in candidate_data.files}

# Compute article vector
def compute_article_vector(tokens, model):
    valid_tokens = [str(t) for t in tokens if str(t) in model.wv]
    if not valid_tokens:
        return np.zeros(model.vector_size)
    return np.mean(model.wv[valid_tokens], axis=0)

# Cosine similarity
def cosine_similarity(vec_a, vec_b):
    denom = norm(vec_a) * norm(vec_b)
    if denom == 0:
        return 0.0
    return float(np.dot(vec_a, vec_b) / denom)

# Get semantic similarity
def get_semantic_similarity(candidate_id, text_tokens):
    candidate_vec = candidate_expertise_dict.get(candidate_id, np.zeros(w2v_model.vector_size))
    article_vec = compute_article_vector(text_tokens, w2v_model)
    return cosine_similarity(candidate_vec, article_vec)

# Example
sample_text = [
    64, 1, 322, 134, 136, 396, 270, 144, 476, 481,
    165, 39, 361, 43, 177, 308, 310, 118, 187, 127
]
#candidate_id = 750
#similarity = get_semantic_similarity(candidate_id, sample_text)
#print(f"Cosine similarity for candidate {candidate_id}: {similarity:.4f}")
