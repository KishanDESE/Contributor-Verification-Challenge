# graph_builder.py
import json
import networkx as nx
from collections import defaultdict
from LDACallFunction import get_topic_distribution, ensure_list
import pickle

#Load data

def load_articles(json_file):
    """Load JSON dataset and extract venue, text, contributors."""
    with open(json_file, "r") as f:
        data = json.load(f)

    articles = []
    for article in data.values():
        venue = article.get("article_venue", "")
        text = article.get("text", [])  #[] return empty list
        contributors = ensure_list(article.get("contributor", []))

        articles.append({
            "venue": venue,
            "text": text,
            "contributors": contributors
        })
    return articles





#preprocessing

def preprocess_articles(articles):
    """From raw articles, create coauthor pairs and assign max topic."""
    coauthor_counts = defaultdict(int)
    contributor_topics = defaultdict(int)
    contributor_venues = defaultdict(int)
    venue_topics = defaultdict(int)

    for row in articles:
        contributors = row["contributors"]
        venue = row["venue"]
        text = row["text"]

        if not contributors:
            continue

        # 1. Co-author pairs
        for i in range(len(contributors)):
            for j in range(i+1, len(contributors)):
                c1, c2 = sorted([contributors[i], contributors[j]])
                coauthor_counts[(c1, c2)] += 1

        # 2. Topic inference using LDA
        topic_probs = get_topic_distribution({"text": text})
        max_topic = int(topic_probs.argmax())

        for c in contributors:
            contributor_topics[(c, max_topic)] += 1
            if venue != "":
                contributor_venues[(c, venue)] += 1

        if venue != "":
            venue_topics[(venue, max_topic)] += 1

    return coauthor_counts, contributor_topics, contributor_venues, venue_topics

#Graph Construction

def build_graph(coauthor_counts, contributor_topics, contributor_venues, venue_topics):
    """Construct weighted graph for shortest path scoring."""
    G = nx.Graph()
    eps = 1e-6

    # Contributor���������Contributor
    for (c1, c2), count in coauthor_counts.items():
        G.add_edge(f"contrib_{c1}", f"contrib_{c2}", weight=1/(count+eps))

    # Contributor���������Topic
    for (c, t), count in contributor_topics.items():
        G.add_edge(f"contrib_{c}", f"topic_{t}", weight=1/(count+eps))

    # Contributor���������Venue
    for (c, v), count in contributor_venues.items():
        G.add_edge(f"contrib_{c}", f"venue_{v}", weight=1/(count+eps))

    # Venue���������Topic
    for (v, t), count in venue_topics.items():
        G.add_edge(f"venue_{v}", f"topic_{t}", weight=1/(count+eps))

    return G

#Function calls for shortest path

# ============ Shortest path functions ============
# Load the default graph
try:
    with open("train_graph.pkl", "rb") as f:
        G_DEFAULT = pickle.load(f)
except FileNotFoundError:
    raise FileNotFoundError("train_graph.pkl not found. Please generate or place it in the working directory.")





def shortest_path_to_coauthors(candidate, coauthors, G=G_DEFAULT):
    """Return minimum shortest path length from candidate to any coauthor."""
    candidate_node = f"contrib_{candidate}"
    min_dist = float("inf")
    for co in coauthors:
        co_node = f"contrib_{co}"
        try:
            dist = nx.shortest_path_length(G, candidate_node, co_node, weight="weight")
            min_dist = min(min_dist, dist)
        except nx.NetworkXNoPath:
            continue
    return min_dist if min_dist < float("inf") else 100


def shortest_path_between_contributors(contributor1, contributor2, G=G_DEFAULT):
    """Return shortest path length between two contributors in the graph G."""
    node1 = f"contrib_{contributor1}"
    node2 = f"contrib_{contributor2}"
    try:
        return nx.shortest_path_length(G, node1, node2, weight="weight")
    except nx.NetworkXNoPath:
        return 100
    except nx.NodeNotFound as e:
        raise ValueError(f"Node not found in graph: {e}")


def shortest_path_to_topic(candidate, topic, G=G_DEFAULT):
    """Shortest path from candidate to a topic node."""
    candidate_node = f"contrib_{candidate}"
    topic_node = f"topic_{topic}"
    try:
        return nx.shortest_path_length(G, candidate_node, topic_node, weight="weight")
    except nx.NetworkXNoPath:
        return 100


def shortest_path_to_venue(candidate, venue, G=G_DEFAULT):
    """Shortest path from candidate to a venue node."""
    candidate_node = f"contrib_{candidate}"
    venue_node = f"venue_{venue}"
    try:
        return nx.shortest_path_length(G, candidate_node, venue_node, weight="weight")
    except nx.NetworkXNoPath:
        return 100


def degree_centrality_candidate(candidate, G=G_DEFAULT):
    """Returns the degree (number of edges) of the candidate node."""
    candidate_node = f"contrib_{candidate}"
    if candidate_node in G:
        return G.degree(candidate_node)
    else:
        return 0


def hops_to_venue(candidate, venue, G=G_DEFAULT):
    """Returns hop count (ignores edge weights) from candidate to a venue node."""
    candidate_node = f"contrib_{candidate}"
    venue_node = f"venue_{venue}"
    try:
        return nx.shortest_path_length(G, candidate_node, venue_node)
    except nx.NetworkXNoPath:
        return 100


def hops_to_topic(candidate, topic, G=G_DEFAULT):
    """Returns hop count (ignores edge weights) from candidate to a topic node."""
    candidate_node = f"contrib_{candidate}"
    topic_node = f"topic_{topic}"
    try:
        return nx.shortest_path_length(G, candidate_node, topic_node)
    except nx.NetworkXNoPath:
        return 100


if __name__ == "__main__":
    # Step 1: Load data
    articles = load_articles("train.json")

    # Step 2: Preprocess into coauthor/topic/venue relations
    coauthor_counts, contributor_topics, contributor_venues, venue_topics = preprocess_articles(articles)

    # Step 3: Build graph
    G = build_graph(coauthor_counts, contributor_topics, contributor_venues, venue_topics)

    # Step 3a: Save graph to disk
    import pickle

    # Save
    with open("train_graph.pkl", "wb") as f:
        pickle.dump(G, f)

    # Load
    with open("train_graph.pkl", "rb") as f:
        G = pickle.load(f)


    # Step 4: Test on first 10 rows
    for i, row in enumerate(articles[:10]):
        if not row["contributors"]:
            continue
        candidate = row["contributors"][0]
        coauthors = row["contributors"][1:]
        
        # Compute LDA topic
        topic_probs = get_topic_distribution({"text": row["text"]})
        max_topic = int(topic_probs.argmax())
        venue = row["venue"]

        print(f"\n=== Article {i} ===")
        print("Candidate:", candidate, "Coauthors:", coauthors, "Topic:", max_topic, "Venue:", venue)

        dist_coauthors = shortest_path_to_coauthors(G, candidate, coauthors) if coauthors else None
        dist_topic = shortest_path_to_topic(G, candidate, max_topic)
        dist_venue = shortest_path_to_venue(G, candidate, venue) if venue != "" else None

        print("Shortest path to coauthors:", dist_coauthors)
        print("Shortest path to topic:", dist_topic)
        print("Shortest path to venue:", dist_venue)
        degree = degree_centrality_candidate(G, candidate)
        hops_topic = hops_to_topic(G, candidate, max_topic)
        hops_venue = hops_to_venue(G, candidate, venue) if venue != "" else None
        print("Degree of candidate:", degree)
        print("Hops to topic:", hops_topic)
        print("Hops to venue:", hops_venue)