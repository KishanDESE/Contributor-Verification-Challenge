import json
import numpy as np
from gensim import models

# --------------------------
# Load trained LDA model
# --------------------------
lda_model = models.LdaModel.load("lda_best_coherence.model")
num_topics = lda_model.num_topics
print(num_topics)

# --------------------------
# Helper functions (same as training)
# --------------------------
def ensure_list(x):
    """Ensure input is a list."""
    return x if isinstance(x, list) else [x]

#Remove token 496 as it was in 60% data
def filter_tokens(doc):
    return [token for token in doc if token in lda_model.id2word]


def doc2bow_from_ids(doc):
    """Convert a list of IDs into bag-of-words representation."""
    counts = {}
    for token in doc:
        counts[token] = counts.get(token, 0) + 1
    return list(counts.items())  # [(id, count), ...]


# --------------------------
# Inference function
# --------------------------
def get_topic_distribution(row_json):
    """
    Given a JSON row like {"text": [IDs]},
    return NumPy array of topic probabilities with shape (num_topics,).
    """
    # Ensure list
    tokens = ensure_list(row_json["text"])

    # Filter with training-kept tokens
    filtered_tokens = filter_tokens(tokens)

    # Convert to BoW (IDs are unchanged, same as training)
    bow = doc2bow_from_ids(filtered_tokens)

    # Get topic probabilities with 0 for missing topics
    topic_probs = lda_model.get_document_topics(bow, minimum_probability=0)

    # Convert to numpy array sorted by topic index
    return np.array([prob for (_, prob) in sorted(topic_probs, key=lambda x: x[0])])


# --------------------------
# Batch inference (optional)
# --------------------------
def get_topic_matrix(rows_json):
    """
    Given a list of JSON rows [{"text": [...]}, ...],
    return NumPy matrix of shape (num_docs, num_topics).
    """
    return np.vstack([get_topic_distribution(row) for row in rows_json])


# --------------------------
# Example usage
# --------------------------
if __name__ == "__main__":
    # Example row
    example_row = {"text": [101, 405, 302, 405]}
    probs = get_topic_distribution(example_row)
    print("Topic distribution:", probs)
    print("Shape:", probs.shape)

    # Example batch
    example_rows = [
        {"text": [101, 203, 405]},
        {"text": [500, 600, 700]}
    ]
    matrix = get_topic_matrix(example_rows)
    print("Batch matrix shape:", matrix.shape)
