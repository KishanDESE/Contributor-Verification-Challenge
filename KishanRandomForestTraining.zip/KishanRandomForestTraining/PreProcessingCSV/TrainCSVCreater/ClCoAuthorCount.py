# load_and_query_coauthor_features.py
import numpy as np

# Load saved candidate co-author dictionary
candidate_coauthors_dict = np.load('candidate_coauthors_dict.npy', allow_pickle=True).item()

def get_coauthor_features(candidate_id, contributor_list):
    """
    Given candidate_id and a list of contributors (from a single article),
    returns [max_coauthor_count, avg_coauthor_count].
    """
    if not contributor_list or candidate_id not in contributor_list:
        # If candidate not in article, return 0
        return [0, 0.0]

    # Get stored candidate-level max/avg
    candidate_max, candidate_avg = candidate_coauthors_dict.get(candidate_id, [0, 0.0])

    # Adjust for single contributor
    if len(contributor_list) == 1:
        return [0, 0.0]

    return [candidate_max, candidate_avg]

# ============================
# Example Usage
# ============================
if __name__ == "__main__":
    candidate = 1605
    contributors = [759]
    max_count, avg_count = get_coauthor_features(candidate, contributors)
    print(f"Candidate {candidate} co-author features: max={max_count}, avg={avg_count:.2f}")
