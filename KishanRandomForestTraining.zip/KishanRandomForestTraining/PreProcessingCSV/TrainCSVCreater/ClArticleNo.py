# load_and_query_contributor_articles.py
import numpy as np

# Load the saved npz
contributor_data = np.load("contributor_article_count.npz", allow_pickle=True)
# Convert keys back to int for easy lookup
contributor_article_count = {int(k): contributor_data[k] for k in contributor_data.files}

def get_article_count(contributor_id):
    """
    Returns the total number of articles written by the given contributor_id.
    If contributor_id does not exist, returns 0.
    """
    return contributor_article_count.get(contributor_id, 0)

# Example usage
if __name__ == "__main__":
    contributor_id = 1605
    count = get_article_count(contributor_id)
    print(f"Contributor {contributor_id} has written {count} articles.")
