import json
import matplotlib.pyplot as plt
import numpy as np
from gensim import corpora, models
from sklearn.manifold import TSNE
import umap.umap_ as umap
from sklearn.metrics import confusion_matrix
import seaborn as sns
from collections import defaultdict
from sklearn.feature_extraction.text import TfidfVectorizer
from gensim.corpora import Dictionary
import os
from multiprocessing import Pool
from joblib import Parallel, delayed


# Restrict to 120 threads to match your actual hardware
os.environ["OMP_NUM_THREADS"] = "120"
os.environ["OPENBLAS_NUM_THREADS"] = "120" 
os.environ["MKL_NUM_THREADS"] = "120"
os.environ["VECLIB_MAXIMUM_THREADS"] = "120"
os.environ["NUMEXPR_NUM_THREADS"] = "120"


# --------------------------
# Load JSON
# --------------------------
with open("/home/kishan/Documents/MLCPS3/train.json", "r") as f:
    train_data = json.load(f)
with open("/home/kishan/Documents/MLCPS3/test.json", "r") as f:
    test_data = json.load(f)


# --------------------------
# Ensure all entries are lists since some rows have single values instead of lists.
# --------------------------
def ensure_list(x):
    return x if isinstance(x, list) else [x]


# Normalize all documents to lists of IDs
train_texts = [ensure_list(entry["text"]) for entry in train_data.values()]
test_texts  = [ensure_list(entry["text"]) for entry in test_data.values()]

# --------------------------
# Count in how many documents each token appears (Document Frequency)
# --------------------------
df = defaultdict(int)  # default value 0 for each token

for doc in train_texts:
    unique_tokens = set(doc)  # consider each token only once per document
    for token in unique_tokens:
        df[token] += 1  # increment count for this token

num_docs = len(train_texts)  # total number of documents

print(f"Total aricles: {num_docs}")
print(f"Total unique text IDs: {len(df)}")


# --------------------------
# TF-IDF filtering
# Remove common texts and rare text Ids from data
# --------------------------
# Use TfidfVectorizer with tokenizer that returns the token list directly
vectorizer = TfidfVectorizer(
    tokenizer=lambda x: x,  # already tokenized lists
    lowercase=False,        # token IDs, no need to lowercase
    min_df=2,               # token must appear in at least 2 documents
    max_df=0.6              # token can appear in at most 95% of documents
)

# Fit on train_texts
tfidf_matrix = vectorizer.fit_transform(train_texts)

# Tokens that survived filtering
filtered_tokens = vectorizer.get_feature_names_out()  # returns strings
filtered_tokens = [int(t) for t in filtered_tokens]   # convert back to int

# Calculate rare and common tokens removed
all_tokens = set(df.keys())
kept_tokens = set(filtered_tokens)
rare_or_common_tokens_removed = all_tokens - kept_tokens

print(f"Total text IDs before filtering: {len(all_tokens)}")
print(f"Total text IDs kept after TF-IDF filtering: {len(kept_tokens)}")
print(f"Total text IDs filtered out (rare or common): {len(rare_or_common_tokens_removed)}")


# Print removed token IDs
print("Token IDs removed (rare or too common):")
print(sorted(rare_or_common_tokens_removed))

# --------------------------
# Filter train and test texts using filtered_tokens
# --------------------------
def filter_tokens(doc, allowed_tokens):
    return [token for token in doc if token in allowed_tokens]

train_texts_filtered = [filter_tokens(doc, kept_tokens) for doc in train_texts]
test_texts_filtered  = [filter_tokens(doc, kept_tokens) for doc in test_texts]



# --------------------------
# Bag-of-Words from IDs (frequency count of IDs per document)
# This code ensure token IDs are same number not remaped to new numbers.
# --------------------------
def doc2bow_from_ids(doc):
    """Convert a list of IDs into a bag-of-words representation."""
    counts = {}
    for token in doc:  # token is already an int ID
        counts[token] = counts.get(token, 0) + 1
    return list(counts.items())  # Returns [(id, count), ...] e.g. {"101": 0, "203": 1}

# --------------------------
# Prepare corpus
# --------------------------
# Calling doc2bow_from_ids
train_corpus = [doc2bow_from_ids(text) for text in train_texts_filtered]
test_corpus  = [doc2bow_from_ids(text) for text in test_texts_filtered]

# Build id2word mapping for gensim (needed for LDA to print topics)
# As liabraries display text not IDs inherently so created text same as IDs as we have given IDs only.
# lda.print_topics() will give suppose topic index 0 distribution : 0.3*"101" + 0.2*"405"
unique_ids = sorted({id_ for doc in train_texts_filtered for id_ in doc})
id2word = {id_: str(id_) for id_ in unique_ids}



# --------------------------
# Train LDA with multiple topics
# --------------------------
perplexities = []
coherences = []
topic_assignments = {}
 # genism coherence need genism dictionary
# Convert integer token IDs to strings for gensim Dictionary
train_texts_filtered_str = [[str(token) for token in doc] for doc in train_texts_filtered]

# Create gensim Dictionary (strings only)
dictionary = Dictionary(train_texts_filtered_str)


# --------------------------
# Modified LDA training approach
# --------------------------
# Instead of using multiprocessing.Pool, we'll use a sequential approach
# but with LdaMulticore for each model, and we'll manually control parallelism

# --------------------------
# Modified LDA training approach using joblib
# --------------------------
from joblib import Parallel, delayed

# Define workers per model
workers_per_model = 10

# Function to train a single LDA model
def train_single_lda(num_topics):
    print(f"Training LDA with {num_topics} topics...")
    lda = models.LdaMulticore(
        corpus=train_corpus,
        id2word=id2word,
        num_topics=num_topics,
        passes=20,
        iterations=500,
        workers=workers_per_model,
        random_state=42
    )
    
    # Test corpus perplexity
    test_perplexity = lda.log_perplexity(test_corpus)

    # Train coherence (u_mass)
    cm_train = models.CoherenceModel(
        model=lda,
        texts=train_texts_filtered_str,
        dictionary=dictionary,
        coherence='u_mass'
    )
    train_coherence = cm_train.get_coherence()

    # Assign dominant topic for each document in test corpus
    topic_assignments = [
        max(lda[doc], key=lambda x: x[1])[0] if len(lda[doc]) > 0 else -1
        for doc in test_corpus
    ]
    
    print(f"Completed: topics={num_topics}, perplexity={test_perplexity:.4f}, coherence={train_coherence:.4f}")
    return (num_topics, lda, test_perplexity, train_coherence, topic_assignments)

# Train all models in parallel
topic_range = range(20, 40)  # 20 to 40 topics
all_results = Parallel(n_jobs=12)(delayed(train_single_lda)(num_topics) for num_topics in topic_range)

# Sort results by number of topics to maintain order
all_results.sort(key=lambda x: x[0])

# --------------------------
# Extract metrics
# --------------------------
test_perplexities = [r[2] for r in all_results]
train_coherences = [r[3] for r in all_results]
topic_assignments = {r[0]: r[4] for r in all_results}
# --------------------------
# Determine best number of topics
# --------------------------
best_coherence_idx = np.argmax(train_coherences)
best_coherence_num_topics = topic_range[best_coherence_idx]
best_coherence_score = train_coherences[best_coherence_idx]

best_perplexity_idx = np.argmin(test_perplexities)
best_perplexity_num_topics = topic_range[best_perplexity_idx]
best_perplexity_score = test_perplexities[best_perplexity_idx]

print(f"Best number of topics by train coherence: {best_coherence_num_topics} (Coherence={best_coherence_score:.4f})")
print(f"Best number of topics by test perplexity: {best_perplexity_num_topics} (Log Perplexity={best_perplexity_score:.4f})")

# --------------------------
# Plot test metrics
# --------------------------
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.plot(topic_range, test_perplexities, marker='o')
plt.title("LDA Test Perplexity")
plt.xlabel("Num Topics")
plt.ylabel("Log Perplexity")

plt.subplot(1, 2, 2)
plt.plot(topic_range, train_coherences, marker='o', color='orange')
plt.title("LDA Train Coherence")
plt.xlabel("Num Topics")
plt.ylabel("Coherence Score")

plt.tight_layout()
plt.savefig("lda_test_metrics.png", dpi=600)
plt.close()



# --------------------------
# Plot train metrics separately
# --------------------------
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.plot(topic_range, train_coherences, marker='o', color='green')
plt.title("LDA Train Coherence")
plt.xlabel("Num Topics")
plt.ylabel("Coherence Score")

plt.subplot(1, 2, 2)
plt.plot(topic_range, test_perplexities, marker='o', color='red')
plt.title("LDA Test Perplexity")
plt.xlabel("Num Topics")
plt.ylabel("Log Perplexity")

plt.tight_layout()
plt.savefig("lda_train_metrics.png", dpi=600)
plt.close()

workers_per_model = 120

best_lda_coherence = models.LdaMulticore(corpus=train_corpus,
                           id2word=id2word,
                           num_topics=best_coherence_num_topics,
                           random_state=42,
                           passes=20,
                           iterations=500,
                           workers=workers_per_model)

best_lda_perplexity = models.LdaMulticore(corpus=train_corpus,
                           id2word=id2word,
                           num_topics=best_perplexity_num_topics,
                           random_state=42,
                           passes=20,
                           iterations=500,
                           workers=workers_per_model)

# Save the LDA model with best coherence
best_lda_coherence.save("lda_best_coherence.model")
print("Saved LDA model with best coherence to 'lda_best_coherence.model'")

# Save the LDA model with best perplexity
best_lda_perplexity.save("lda_best_perplexity.model")
print("Saved LDA model with best perplexity to 'lda_best_perplexity.model'")


# --------------------------
# UMAP for best coherence model
# --------------------------
best_lda_coherence = models.LdaModel.load("lda_best_coherence.model")

doc_topics_coherence = [max(best_lda_coherence[doc], key=lambda x: x[1])[0] if len(best_lda_coherence[doc])>0 else -1
                        for doc in test_corpus]

doc_topic_matrix_coherence = [best_lda_coherence.get_document_topics(doc, minimum_probability=0)
                              for doc in test_corpus]
doc_topic_matrix_coherence = np.array([[prob for (_, prob) in row] for row in doc_topic_matrix_coherence])

reducer = umap.UMAP(random_state=42)
embedding_coherence = reducer.fit_transform(doc_topic_matrix_coherence)

plt.figure(figsize=(10,7))
plt.scatter(embedding_coherence[:,0], embedding_coherence[:,1], c=doc_topics_coherence, cmap="tab20", s=20)
plt.colorbar()
plt.title(f"2D UMAP clustering - Best Coherence ({best_lda_coherence.num_topics} topics)")
plt.tight_layout()
plt.savefig("umap_2d_best_coherence.png", dpi=300)
plt.close()

# --------------------------
# Histogram of dominant topics - Best Coherence
# --------------------------
dominant_topics_coherence = np.argmax(doc_topic_matrix_coherence, axis=1)
plt.figure(figsize=(12,6))
plt.hist(dominant_topics_coherence, bins=best_lda_coherence.num_topics, color='skyblue', edgecolor='black')
plt.xlabel("Dominant Topic")
plt.ylabel("Number of Documents")
plt.title("Histogram of Dominant Topics - Best Coherence Model")
plt.tight_layout()
plt.savefig("histogram_best_coherence.png", dpi=300)
plt.close()

# --------------------------
# Average topic probabilities - Best Coherence
# --------------------------
avg_topic_probs_coherence = np.mean(doc_topic_matrix_coherence, axis=0)
plt.figure(figsize=(12,6))
plt.bar(range(best_lda_coherence.num_topics), avg_topic_probs_coherence, color='orange', edgecolor='black')
plt.xlabel("Topic")
plt.ylabel("Average Topic Probability")
plt.title("Average Topic Probabilities - Best Coherence Model")
plt.tight_layout()
plt.savefig("avg_probs_best_coherence.png", dpi=300)
plt.close()


# --------------------------
# UMAP for best perplexity model
# --------------------------
best_lda_perplexity = models.LdaModel.load("lda_best_perplexity.model")

doc_topics_perplexity = [max(best_lda_perplexity[doc], key=lambda x: x[1])[0] if len(best_lda_perplexity[doc])>0 else -1
                         for doc in test_corpus]

doc_topic_matrix_perplexity = [best_lda_perplexity.get_document_topics(doc, minimum_probability=0)
                               for doc in test_corpus]
doc_topic_matrix_perplexity = np.array([[prob for (_, prob) in row] for row in doc_topic_matrix_perplexity])

embedding_perplexity = reducer.fit_transform(doc_topic_matrix_perplexity)

plt.figure(figsize=(10,7))
plt.scatter(embedding_perplexity[:,0], embedding_perplexity[:,1], c=doc_topics_perplexity, cmap="tab20", s=20)
plt.colorbar()
plt.title(f"2D UMAP clustering - Best Perplexity ({best_lda_perplexity.num_topics} topics)")
plt.tight_layout()
plt.savefig("umap_2d_best_perplexity.png", dpi=300)
plt.close()

# --------------------------
# Histogram of dominant topics - Best Perplexity
# --------------------------
dominant_topics_perplexity = np.argmax(doc_topic_matrix_perplexity, axis=1)
plt.figure(figsize=(12,6))
plt.hist(dominant_topics_perplexity, bins=best_lda_perplexity.num_topics, color='skyblue', edgecolor='black')
plt.xlabel("Dominant Topic")
plt.ylabel("Number of Documents")
plt.title("Histogram of Dominant Topics - Best Perplexity Model")
plt.tight_layout()
plt.savefig("histogram_best_perplexity.png", dpi=300)
plt.close()

# --------------------------
# Average topic probabilities - Best Perplexity
# --------------------------
avg_topic_probs_perplexity = np.mean(doc_topic_matrix_perplexity, axis=0)
plt.figure(figsize=(12,6))
plt.bar(range(best_lda_perplexity.num_topics), avg_topic_probs_perplexity, color='orange', edgecolor='black')
plt.xlabel("Topic")
plt.ylabel("Average Topic Probability")
plt.title("Average Topic Probabilities - Best Perplexity Model")
plt.tight_layout()
plt.savefig("avg_probs_best_perplexity.png", dpi=300)
plt.close()