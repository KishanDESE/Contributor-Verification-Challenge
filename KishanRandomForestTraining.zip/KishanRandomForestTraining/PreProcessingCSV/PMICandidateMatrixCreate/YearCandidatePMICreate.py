# save_contributor_year_pmi.py
import json
import numpy as np
from collections import defaultdict

def calculate_contributor_year_pmi(data):
    contributors_years = []
    all_train_years = set()
    papers = [details['contributor'] for details in data.values()]
    num_papers = len(papers)

    all_authors = sorted(list(set(author for paper in papers for author in paper)))
    author_to_idx = {author: i for i, author in enumerate(all_authors)}
    num_authors = len(all_authors)

    author_counts = defaultdict(int)
    for paper in papers:
        for author in set(paper):
            author_counts[author] += 1

    for details in data.values():
        contributors = details['contributor']
        year = details['article_year']
        # Handle both single contributor and list of contributors
        if isinstance(contributors, list):
            for contributor in contributors:
                contributors_years.append((contributor, year))
                all_train_years.add(year)
        else:
            contributors_years.append((contributors, year))
            all_train_years.add(year)

    all_train_years = sorted(list(all_train_years))
    train_year_to_idx = {year: i for i, year in enumerate(all_train_years)}
    num_train_years = len(all_train_years)

    contributor_year_counts = defaultdict(int)
    train_year_counts = defaultdict(int)

    for contributor, year in contributors_years:
        train_year_counts[year] += 1
        contributor_year_counts[(contributor, year)] += 1

    contributor_year_pmi_matrix = np.zeros((num_authors, num_train_years))
    num_train_papers_for_year = len(contributors_years)

    for i in range(num_authors):
        for j in range(num_train_years):
            contributor = all_authors[i]
            year = all_train_years[j]

            prob_contributor = author_counts.get(contributor, 0) / num_papers
            prob_year = train_year_counts.get(year, 0) / num_train_papers_for_year
            prob_contributor_year = contributor_year_counts.get((contributor, year), 0) / num_train_papers_for_year

            if prob_contributor_year > 0 and prob_contributor > 0 and prob_year > 0:
                pmi = np.log2(prob_contributor_year / (prob_contributor * prob_year))
                contributor_year_pmi_matrix[i, j] = pmi
            else:
                contributor_year_pmi_matrix[i, j] = -1  # No co-occurrence

    return contributor_year_pmi_matrix, all_authors, all_train_years, train_year_to_idx


if __name__ == "__main__":
    file_path = 'train.json'
    with open(file_path, 'r') as f:
        data = json.load(f)

    pmi_matrix, all_authors, all_years, year_to_idx = calculate_contributor_year_pmi(data)

    # Save as numpy .npz
    np.savez("contributor_year_pmi.npz",
             pmi_matrix=pmi_matrix,
             all_authors=np.array(all_authors),
             all_years=np.array(all_years))
    print("Contributor-Year PMI saved to 'contributor_year_pmi.npz'")
