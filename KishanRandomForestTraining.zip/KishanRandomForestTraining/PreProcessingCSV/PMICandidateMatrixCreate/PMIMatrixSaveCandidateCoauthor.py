import json
import numpy as np
from itertools import combinations
from collections import Counter
import random

# ---------- Helper ----------
def ensure_list(x):
    return x if isinstance(x, list) else [x] if x is not None else []

# ---------- Load Data ----------
with open("train.json", "r") as f:
    data = json.load(f)   # dict keyed by article IDs

# Collect all contributor sets (from dict values)
articles_contributors = [ensure_list(article.get("contributor", [])) for article in data.values()]

# Build contributor universe (all unique IDs)
all_contributors = sorted(set(c for contributors in articles_contributors for c in contributors))
contributor_index = {c: i for i, c in enumerate(all_contributors)}
n = len(all_contributors)

# ---------- Count co-occurrences ----------
pair_counter = Counter()
contrib_counter = Counter()

for contributors in articles_contributors:
    unique_contribs = set(contributors)  # avoid double-counting within same article
    for c in unique_contribs:
        contrib_counter[c] += 1
    for c1, c2 in combinations(unique_contribs, 2):
        pair = tuple(sorted((c1, c2)))
        pair_counter[pair] += 1

# ---------- Probabilities ----------
total_pairs = sum(pair_counter.values())
total_single = sum(contrib_counter.values())

# PMI matrix
PMI = np.zeros((n, n), dtype=np.float32)

for (c1, c2), count in pair_counter.items():
    p_xy = count / total_pairs
    p_x = contrib_counter[c1] / total_single
    p_y = contrib_counter[c2] / total_single
    pmi = np.log(p_xy / (p_x * p_y) + 1e-12)  # add epsilon to avoid log(0)
    i, j = contributor_index[c1], contributor_index[c2]
    PMI[i, j] = pmi
    PMI[j, i] = pmi  # symmetric

# Save matrix and contributor index
np.save("PMI_CandidateMax.npy", PMI)
with open("contributor_index.json", "w") as f:
    json.dump(contributor_index, f)

print(f"PMI matrix saved with shape {PMI.shape}")
print("Contributor index saved to contributor_index.json")

# ---------- Print sample outputs ----------
print("\nSample Contributor Pairs with PMI values:\n")
pairs_checked = 0
for (c1, c2), count in pair_counter.items():
    i, j = contributor_index[c1], contributor_index[c2]
    print(f"Contributors ({c1}, {c2}) -> PMI = {PMI[i, j]:.4f}")
    pairs_checked += 1
    if pairs_checked >= 10:  # only print 10
        break
