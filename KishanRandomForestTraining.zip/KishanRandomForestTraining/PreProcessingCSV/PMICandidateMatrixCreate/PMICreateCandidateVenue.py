# save_author_venue_pmi.py
import json
import numpy as np
from collections import defaultdict

def calculate_author_venue_pmi(data):
    authors_venues = []
    all_venues = set()
    papers = [details['contributor'] for details in data.values()]
    num_papers = len(papers)

    all_authors = sorted(list(set(author for paper in papers for author in paper)))
    author_to_idx = {author: i for i, author in enumerate(all_authors)}
    num_authors = len(all_authors)

    author_counts = defaultdict(int)
    for paper in papers:
        for author in set(paper):
            author_counts[author] += 1

    for details in data.values():
        authors = details['contributor']
        venue = details['article_venue']
        if venue != '':  # Exclude empty venues
            authors_venues.append((authors, venue))
            all_venues.add(venue)

    all_venues = sorted(list(all_venues))
    venue_to_idx = {venue: i for i, venue in enumerate(all_venues)}
    num_venues = len(all_venues)

    author_venue_counts = defaultdict(int)
    venue_counts = defaultdict(int)

    for authors, venue in authors_venues:
        venue_counts[venue] += 1
        for author in set(authors):
            author_venue_counts[(author, venue)] += 1

    author_venue_pmi_matrix = np.zeros((num_authors, num_venues))
    num_papers_with_venue = len(authors_venues)

    for i in range(num_authors):
        for j in range(num_venues):
            author = all_authors[i]
            venue = all_venues[j]

            prob_author = author_counts[author] / num_papers
            prob_venue = venue_counts[venue] / num_papers_with_venue
            prob_author_venue = author_venue_counts.get((author, venue), 0) / num_papers_with_venue

            if prob_author_venue > 0 and prob_author > 0 and prob_venue > 0:
                pmi = np.log2(prob_author_venue / (prob_author * prob_venue))
                author_venue_pmi_matrix[i, j] = pmi
            else:
                author_venue_pmi_matrix[i, j] = -1  # No co-occurrence

    return author_venue_pmi_matrix, all_authors, all_venues, venue_to_idx


if __name__ == "__main__":
    file_path = 'train.json'
    with open(file_path, 'r') as f:
        data = json.load(f)

    # Exclude papers with empty venue
    data = {k: v for k, v in data.items() if v['article_venue'] != ''}

    pmi_matrix, all_authors, all_venues, venue_to_idx = calculate_author_venue_pmi(data)

    # Save as numpy .npz
    np.savez("author_venue_pmi.npz",
             pmi_matrix=pmi_matrix,
             all_authors=np.array(all_authors),
             all_venues=np.array(all_venues))
    print("Author-Venue PMI saved to 'author_venue_pmi.npz'")
