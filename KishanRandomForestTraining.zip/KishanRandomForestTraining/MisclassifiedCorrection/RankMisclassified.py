import pandas as pd

# Load the two CSV files
with_candidate = pd.read_csv("ProbabilityWithCandidaterf_test_predictions.csv")
no_contri = pd.read_csv("NoContrirf_test_predictions.csv")

# Ensure id types match
with_candidate["id"] = with_candidate["id"].astype(str)
no_contri["id"] = no_contri["id"].astype(str)

# Step 1: Filter misclassified (class 1 predicted as 0)
misclassified = with_candidate[with_candidate["predictions"] == 0]

# Step 2: Merge with NoContri probabilities
merged = misclassified.merge(
    no_contri[["id", "probability"]].rename(columns={"probability": "probability_noContri"}),
    on="id",
    how="left"
)

# Step 3: Rename WithCandidate probability properly
merged.rename(columns={"probability": "probability_with"}, inplace=True)

# Step 4: Compute average probability
merged["avg_probability"] = (merged["probability_with"] + merged["probability_noContri"]) / 2

# Step 5: Rank misclassified by avg_probability (descending)
ranked = merged.sort_values(by="avg_probability", ascending=False).reset_index(drop=True)

# Add Rank column
ranked.insert(0, "Rank(According to average)", ranked.index + 1)

# Step 6: Save full ranking for reference
ranked.to_csv(
    "Ranked_misclassified.csv",
    index=False,
    columns=[
        "Rank(According to average)", 
        "id", 
        "predictions", 
        "probability_with", 
        "probability_noContri", 
        "avg_probability"
    ]
)

print("Saved as Ranked_misclassified.csv")

# Step 7: Take top 130 ids and flip their prediction from 0 → 1
top_ids = ranked.head(130)[["id", "avg_probability"]]

# Step 8: Create a copy of WithCandidate predictions
modified_with_candidate = with_candidate.copy()

# Flip predictions for top 130
modified_with_candidate.loc[
    modified_with_candidate["id"].isin(top_ids["id"]), "predictions"
] = 1

# Replace probability with avg_probability for those top 130 ids
modified_with_candidate = modified_with_candidate.merge(
    top_ids.rename(columns={"avg_probability": "new_probability"}),
    on="id",
    how="left"
)
modified_with_candidate["probability"] = modified_with_candidate["new_probability"].fillna(
    modified_with_candidate["probability"]
)
modified_with_candidate.drop(columns=["new_probability"], inplace=True)

# Step 9: Save final RandomFores.csv with probability included
modified_with_candidate.to_csv("ProbabilityRandomForest.csv", index=False)

print("Saved as RandomFores.csv (with updated probability column)")
