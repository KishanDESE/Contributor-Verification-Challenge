#!/usr/bin/env python3
"""
Balanced Random Forest training for coauthor prediction with OOB validation.
Plots training, OOB, and validation loss in a high-quality image.
"""

import glob
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss
from imblearn.ensemble import BalancedRandomForestClassifier
import matplotlib.pyplot as plt
import joblib
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# ----------------------------
# Step 1: Load all CSV files
# ----------------------------
csv_files = glob.glob("train_feature_with_TopicPMITh*.csv")
df_list = [pd.read_csv(f) for f in csv_files]
data = pd.concat(df_list, ignore_index=True)
print(f"Total rows loaded: {len(data)}")

# ----------------------------
# Step 2: Define features
# ----------------------------

#Importantfeatures
feature_cols = []
feature_cols += ["VenuePMI", "H2V", "H2T", "N2Vsim","YearPMI","NumContributor","TopicPMI","C_TDist"]
# #All features
# feature_cols = ["N2Vsim"]  
# #feature_cols += [f"Topic{i}" for i in range(21)]
# feature_cols += ["C_CDist", "C_TDist", "C_VDist", "Degree", "H2V", "H2T"]
# feature_cols += ["ArticleCount", "W2V", "AvgContributor"]
# #feature_cols += ["C_CPMI", "VenuePMI", "YearPMI", "NumContributor"]
# feature_cols += ["C_CPMI", "VenuePMI", "YearPMI", "NumContributor"]
# # feature_cols += ["venue", "topic", "year"]
# feature_cols += ["TopicPMI"]
# feature_cols += ["Tharun_avg_coauthor_count"]

X = data[feature_cols].fillna(0).replace([np.inf, -np.inf], 0)
y = data["label"]

# ----------------------------
# Step 3: Train / Validation Split
# ----------------------------
X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.3, stratify=y, random_state=42
)
print(f"Training rows: {len(X_train)}, Validation rows: {len(X_val)}")

# ----------------------------
# Step 4: Initialize & Train Balanced Random Forest
# ----------------------------
rf = BalancedRandomForestClassifier(
    n_estimators=3000,
    max_depth=3,
    min_samples_split=100,
    min_samples_leaf=100,
    max_features=0.6,
    sampling_strategy='auto',
    replacement=True,   # bootstrap must be True for OOB
    bootstrap=True,
    oob_score=True,
    random_state=42,
    n_jobs=-1
)

rf.fit(X_train, y_train)
print("Balanced Random Forest trained successfully.")



# After training the model
importances = rf.feature_importances_
feature_importance_df = pd.DataFrame({
    "feature": feature_cols,
    "importance": importances
}).sort_values(by="importance", ascending=False)

print(feature_importance_df)

# ----------------------------
# Step 5: Compute Losses
# ----------------------------
y_train_pred_proba = rf.predict_proba(X_train)[:,1]
train_loss = log_loss(y_train, y_train_pred_proba)

y_oob_pred_proba = rf.oob_decision_function_[:,1]
oob_loss = log_loss(y_train, y_oob_pred_proba)

y_val_pred_proba = rf.predict_proba(X_val)[:,1]
val_loss = log_loss(y_val, y_val_pred_proba)
val_acc = (y_val_pred_proba >= 0.5).astype(int)
val_acc = (val_acc == y_val).mean()

print(f"Training Loss: {train_loss:.4f}")
print(f"OOB Loss: {oob_loss:.4f}")
print(f"Validation Loss: {val_loss:.4f}, Accuracy: {val_acc:.4f}")


# ----------------------------
# Step 6: Plot Losses
# ----------------------------
plt.figure(figsize=(10,6), dpi=300)
plt.bar(["Training", "OOB", "Validation"], [train_loss, oob_loss, val_loss], color=['blue','red','green'])
plt.ylabel("Log Loss")
plt.title("Balanced Random Forest Losses")
plt.tight_layout()
plt.savefig("balanced_rf_loss_curve.png", dpi=300)
plt.close()
print("Loss plot saved as balanced_rf_loss_curve.png")

# ----------------------------
# Confusion Matrix
# ----------------------------
y_val_pred = (rf.predict_proba(X_val)[:,1] >= 0.5).astype(int)  # predicted labels
cm = confusion_matrix(y_val, y_val_pred)

print("Confusion Matrix:")
print(cm)

# Plot confusion matrix
plt.figure(figsize=(6,5), dpi=300)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Balanced Random Forest Confusion Matrix')
plt.tight_layout()
plt.savefig("balanced_rf_confusion_matrix.png", dpi=300)
plt.close()
print("Confusion matrix saved as balanced_rf_confusion_matrix.png")
# ----------------------------
# Step 7: Save trained model
# ----------------------------
joblib.dump(rf, "balanced_rf_coauthor_model.pkl")
print("Balanced Random Forest model saved as balanced_rf_coauthor_model.pkl")
