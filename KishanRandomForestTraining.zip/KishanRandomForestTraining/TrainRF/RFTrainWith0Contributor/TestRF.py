import pandas as pd
import numpy as np
import joblib

# Paths
MODEL_PATH = "balanced_rf_coauthor_model.pkl"  # your saved Random Forest model
TEST_CSV = "zero_only_testPMITh.csv"
OUTPUT_CSV = "rf_test_predictions.csv"

# -------------------------------
# Step 1: Load Test CSV
# -------------------------------
df_test = pd.read_csv(TEST_CSV)
ids = df_test["id"]

# -------------------------------
# Step 2: Define Feature Columns
# -------------------------------
feature_cols = []

# Topic distributions
feature_cols += [f"topic_{i}" for i in range(21)]
feature_cols += ["max_topic"]

# PMI and similarity features
feature_cols += ["PMI_venue", "PMI_year", "word2vecscore"]

# Article and network features
feature_cols += ["ArticleCount", "Topic_Dist", "Venue_Dist", "degree", "Hops2Venue", "Hops2topic"]
feature_cols += ["TopicPMI"]

X_test = df_test[feature_cols]

# -------------------------------
# Step 3: Detect and Fix Problematic Rows
# -------------------------------
nan_mask = X_test.isna().any(axis=1)
inf_mask = np.isinf(X_test).any(axis=1)
problem_rows = nan_mask | inf_mask
num_problem_rows = problem_rows.sum()
print(f"Number of rows with NaN or Inf values: {num_problem_rows}")

# Fill NaN and replace Inf/-Inf
X_test = X_test.fillna(0)
X_test = X_test.replace([np.inf, -np.inf], 0)

# -------------------------------
# Step 4: Load Random Forest Model and Predict
# -------------------------------
model = joblib.load(MODEL_PATH)

# Predict class labels
y_pred_label = model.predict(X_test)

# Predict probabilities for class 1
y_pred_proba = model.predict_proba(X_test)[:, 1]

# -------------------------------
# Step 5: Analyze Class Distribution
# -------------------------------
num_class_0 = np.sum(y_pred_label == 0)
num_class_1 = np.sum(y_pred_label == 1)
print(f"Predicted Class 0 count: {num_class_0}")
print(f"Predicted Class 1 count: {num_class_1}")
print(f"Total predictions: {len(y_pred_label)}")

# -------------------------------
# Step 6: Save Predictions
# -------------------------------
output_df = pd.DataFrame({
    "id": ids,
    "predictions": y_pred_label,
    "probability": y_pred_proba
})

output_df.to_csv(OUTPUT_CSV, index=False)
print(f"Predictions saved to {OUTPUT_CSV}")
