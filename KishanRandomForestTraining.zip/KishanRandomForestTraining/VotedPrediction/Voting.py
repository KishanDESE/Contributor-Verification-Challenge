import pandas as pd

# File paths with their accuracies
files = {
    "72svm_test_predictions.csv": 0.72,
    "78ProbabilityOriginalRandomForest.csv": 0.77,
    "75xgb_test_predictions.csv": 0.75,
    "88predictions_with_proba.csv": 0.88,
    "87ProbabilityRandomForest.csv": 0.87
}

# Load all dataframes and keep only id and probability
dfs = []
for f, acc in files.items():
    df = pd.read_csv(f, usecols=["id", "probability"])
    df = df.rename(columns={"probability": f"prob_{acc}"})
    dfs.append(df)

# Merge all on 'id'
merged = dfs[0]
for df in dfs[1:]:
    merged = merged.merge(df, on="id")

# Compute weighted probability
total_weight = sum(files.values())
merged["probability"] = sum(
    merged[f"prob_{acc}"] * acc for acc in files.values()
) / total_weight

# Compute final predictions
merged["predictions"] = (merged["probability"] >= 0.5).astype(int)

# Keep only required columns
final_df = merged[["id", "predictions"]]

# Save to CSV
final_df.to_csv("Voting_prediction.csv", index=False)

# Print class distribution
counts = final_df["predictions"].value_counts(normalize=True) * 100
counts_abs = final_df["predictions"].value_counts()

print("Class distribution in Voting_prediction.csv:")
for cls in [0, 1]:
    print(f"Class {cls}: {counts_abs.get(cls, 0)} ({counts.get(cls, 0):.2f}%)")
